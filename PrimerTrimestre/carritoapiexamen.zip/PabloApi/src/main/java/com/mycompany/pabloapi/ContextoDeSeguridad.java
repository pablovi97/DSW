/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pabloapi;

import java.security.Principal;
import javax.ws.rs.core.SecurityContext;

/**
 *
 * @author carlos
 */
public class ContextoDeSeguridad implements SecurityContext {

    private boolean secure;
    private UsuarioP usuarioP;
    
    public ContextoDeSeguridad(){}
    
    public ContextoDeSeguridad(UsuarioP usuario, boolean secure) {
                
        this.usuarioP = usuario;
        this.secure = secure;
    }
    
    @Override
    public Principal getUserPrincipal() {
        return getUsuarioP();
    }

    @Override
    public boolean isUserInRole(String role) {
        return getUsuarioP().getRoles().contains(role);
    }

    @Override
    public boolean isSecure() {
        return secure;
    }
    @Override
    public String getAuthenticationScheme() {
        return SecurityContext.FORM_AUTH;
    }
 

    /**
     * @param secure the secure to set
     */
    public void setSecure(boolean secure) {
        this.secure = secure;
    }

    /**
     * @return the usuarioP
     */
    public UsuarioP getUsuarioP() {
        return usuarioP;
    }

    /**
     * @param usuarioP the usuarioP to set
     */
    public void setUsuarioP(UsuarioP usuarioP) {
        this.usuarioP = usuarioP;
    }



 
    
}
