/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pabloapi.service;

import com.mycompany.pabloapi.ContextoDeSeguridad;
import com.mycompany.pabloapi.JWTHelper;
import com.mycompany.pabloapi.UsuarioP;
import java.lang.annotation.Annotation;
import javax.annotation.Priority;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

/**
 *
 * @author alumno
 */
@Provider
@Priority(Priorities.AUTHENTICATION)
public class Filtro implements ContainerRequestFilter {

    @Context
    private ResourceInfo resourceInfo;

    @Override
    public void filter(ContainerRequestContext requestContext) {

        String relativePath = requestContext.getUriInfo().getPath();

        if (relativePath.matches("login")) {
            return;
        } else if (true) {
            return;
        }

        String cabeceraToken = requestContext.getHeaderString(HttpHeaders.AUTHORIZATION);
        if (cabeceraToken == null || cabeceraToken.isEmpty()) {
            requestContext.abortWith(
                    Response.status(Response.Status.FORBIDDEN)
                            .entity("No hay acceso sin autorización")
                            .build()
            );
        } else {
            String token = cabeceraToken.substring("Bearer".length()).trim();
            String nombreUsuario = null;
            int idUsuario = -1;
            String roles = null;
            
            JWTHelper jwt = JWTHelper.getInstance();
            try {
                nombreUsuario = jwt.obtenerNombreUsuario(token);
                roles = jwt.obtenerRoles(token);
                System.out.println("ROLES EN EL FILTRO: " + roles);
                //idUsuario = jwt.obtenerIdUsuario(token);
                System.out.println("ID-USUARIO EN EL FILTRO: " + idUsuario);

                if (!tieneUsuarioRolDelRecurso(requestContext, roles)) {
                    requestContext.abortWith(Response.status(Response.Status.FORBIDDEN)
                            .entity("Sin acceso. No tiene permisos")
                            .build());
                } else {
                    establecerSecurityContext(requestContext, idUsuario, nombreUsuario, roles);
                }

            } catch (Exception ex) {
                requestContext.abortWith(
                        Response.status(Response.Status.FORBIDDEN)
                                .entity("token no válido")
                                .build()
                );
            }

        }
      

    }

    private boolean tieneUsuarioRolDelRecurso(ContainerRequestContext requestContext, String rolesEnToken) {

        //Primero obtenemos la clase y el método que a los que el usuario quiere acceder
        if (resourceInfo != null) {
            String clase = resourceInfo.getResourceClass().getSimpleName();
            String metodo = resourceInfo.getResourceMethod().getName();
            //System.out.println("clase: " + clase + " método: " + metodo);
        }

        //vamos a suponer por defecto que el usuario no tiene acceso al recurso
        boolean usuarioTieneRolDelRecurso = false;

        //como lo más restrictivo debiera ser el método vamos a ver primero los roles declarados en el método
        Annotation rolesDeclaradosEnMetodo = resourceInfo
                .getResourceMethod()
                .getAnnotation(javax.annotation.security.RolesAllowed.class);

        if (rolesDeclaradosEnMetodo == null) {//al no haber roles asociados al método puede acceder todo mundo
            //falta mirar los roles declarado en la clase que sería la segunda condición a tener en cuenta
            Annotation rolesDeclaradosEnClase = resourceInfo
                    .getResourceClass()
                    .getAnnotation(javax.annotation.security.RolesAllowed.class);

            if (rolesDeclaradosEnClase == null) { //en este caso ni la clase ni el método han declarado roles. Luego acceden todos
                usuarioTieneRolDelRecurso = true;
            } else {
                RolesAllowed anotacion = (javax.annotation.security.RolesAllowed) rolesDeclaradosEnClase;
                for (String rol : anotacion.value()) {
                    if (rolesEnToken.toLowerCase().contains(rol.toLowerCase())) {
                        usuarioTieneRolDelRecurso = true;
                    }
                }
            }
        } else { //aquí estamos en el caso que había roles declarados en el método

            RolesAllowed anotacion = (javax.annotation.security.RolesAllowed) rolesDeclaradosEnMetodo;

            for (String rol : anotacion.value()) {
                if (rolesEnToken.toLowerCase().contains(rol.toLowerCase())) {
                    usuarioTieneRolDelRecurso = true;
                }
            }

        }

        return usuarioTieneRolDelRecurso;
    }

    private void establecerSecurityContext(ContainerRequestContext requestContext, int idUsuario, String nombreUsuario, String roles) {
        UsuarioP usuarioP = new UsuarioP();
        usuarioP.setName(nombreUsuario);
        usuarioP.setRoles(roles);
        usuarioP.setId(idUsuario);
        //Ahora establecemos el contextodeseguridad
        ContextoDeSeguridad cds = new ContextoDeSeguridad(usuarioP, requestContext.getSecurityContext().isSecure());
        requestContext.setSecurityContext(cds);
    }

}
