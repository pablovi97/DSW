/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pabloapi;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import java.security.Key;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author carlos
 */
public class JWTHelper {
    
    private static Key key;
    private static JWTHelper jwthelper;
    
    private JWTHelper(){
        key = Keys.secretKeyFor(SignatureAlgorithm.HS256);
    }
    
    public static JWTHelper getInstance(){
        if( jwthelper == null){
            jwthelper = new JWTHelper();
        }
        return jwthelper;
    }
    
    public void changeKey(){
        key = Keys.secretKeyFor(SignatureAlgorithm.HS256);
    }
    
    int duracionMinutos = 30;
    public void setDuracionToken(int minutos){
        this.duracionMinutos = minutos;
    }
    


    public String obtenerToken(int idUsuario, String nombreUsuario, String roles){
        Date expiracion = new Date(System.currentTimeMillis() + 
                TimeUnit.MINUTES.toMillis(duracionMinutos));
        
        String token = Jwts
                .builder()
                .claim("roles", roles)
                .claim("id", idUsuario)
                .setSubject(nombreUsuario)
                .setExpiration(expiracion)
                .signWith(key)
                .compact();
        return token;   
    }

    
    public String obtenerToken(String nombreUsuario, String roles){
        Date expiracion = new Date(System.currentTimeMillis() + 
                TimeUnit.MINUTES.toMillis(duracionMinutos));
        
        String token = Jwts
                .builder()
                .claim("roles", roles)
                .setSubject(nombreUsuario)
                .setExpiration(expiracion)
                .signWith(key)
                .compact();
        return token;   
    }
    
    /**
     * 
     * @param token
     * @return devuelve null si no es un token válido
     */
    public String obtenerRoles(String token) 
    throws ExpiredJwtException, MalformedJwtException{
        
        Jws<Claims> claims = Jwts.parser()
                                       .setSigningKey(key)
                                       .parseClaimsJws(token);
        return (String)claims.getBody().get("roles");
    }
    
    public String obtenerNombreUsuario(String token) 
    throws ExpiredJwtException, MalformedJwtException{
        Jws<Claims> claims = Jwts.parser()
                                       .setSigningKey(key)
                                       .parseClaimsJws(token);
        return claims.getBody().getSubject();        
    }

    public int obtenerIdUsuario(String token) 
    throws ExpiredJwtException, MalformedJwtException{
        Jws<Claims> claims = Jwts.parser()
                                       .setSigningKey(key)
                                       .parseClaimsJws(token);
        return (Integer)claims.getBody().get("id");        
    }

    
    public Jws<Claims> obtenerClaims(String token) 
    throws ExpiredJwtException, MalformedJwtException{
        
        Jws<Claims> claims = Jwts.parser()
                                       .setSigningKey(key)
                                       .parseClaimsJws(token);
        return claims;
    }
        
    
    public UsuarioP obtenerUsuarioP(String token) 
    throws ExpiredJwtException, ExpiredJwtException{
        UsuarioP up= new UsuarioP();
        up.setName(obtenerNombreUsuario(token));
        up.setRoles(obtenerRoles(token));
        return up;
    }
  
}
