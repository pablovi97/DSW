/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ApiRest;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author alumno
 */
@Entity
@Table(name = "foro")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Foro.findAll", query = "SELECT f FROM Foro f")
    , @NamedQuery(name = "Foro.findByIdforo", query = "SELECT f FROM Foro f WHERE f.idforo = :idforo")
    , @NamedQuery(name = "Foro.findByNombreForo", query = "SELECT f FROM Foro f WHERE f.nombreForo = :nombreForo")})
public class Foro implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idforo")
    private Integer idforo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "nombreForo")
    private String nombreForo;
    @JoinColumn(name = "idusuario", referencedColumnName = "idusuario")
    @ManyToOne(optional = false)
    private Usuario idusuario;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idforo")
    private Collection<Mensaje> mensajeCollection;

    public Foro() {
    }

    public Foro(Integer idforo) {
        this.idforo = idforo;
    }

    public Foro(Integer idforo, String nombreForo) {
        this.idforo = idforo;
        this.nombreForo = nombreForo;
    }

    public Integer getIdforo() {
        return idforo;
    }

    public void setIdforo(Integer idforo) {
        this.idforo = idforo;
    }

    public String getNombreForo() {
        return nombreForo;
    }

    public void setNombreForo(String nombreForo) {
        this.nombreForo = nombreForo;
    }

    public Usuario getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(Usuario idusuario) {
        this.idusuario = idusuario;
    }

    @XmlTransient
    public Collection<Mensaje> getMensajeCollection() {
        return mensajeCollection;
    }

    public void setMensajeCollection(Collection<Mensaje> mensajeCollection) {
        this.mensajeCollection = mensajeCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idforo != null ? idforo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Foro)) {
            return false;
        }
        Foro other = (Foro) object;
        if ((this.idforo == null && other.idforo != null) || (this.idforo != null && !this.idforo.equals(other.idforo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ApiRest.Foro[ idforo=" + idforo + " ]";
    }
    
}
