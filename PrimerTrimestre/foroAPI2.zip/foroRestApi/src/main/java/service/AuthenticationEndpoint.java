/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import ApiRest.ManejarDB;
import ApiRest.Usuario;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import java.security.Key;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author alumno
 */
@Path("authentication")
public class AuthenticationEndpoint {
//static Key key;
    @POST
    @Produces("application/json")
    @Consumes({MediaType.APPLICATION_FORM_URLENCODED})
    public Response authenticateUser(@FormParam("usuario") String usuario, @FormParam("password") String password) {
      //String roles = authenticate(usuario, password);//si devuelve null es queno ha sido autenticado
       String roles = "admin";
        String token = null;
        if (roles != null) {
            token = obtenerToken(usuario, roles, 30);
        }
        if (token != null) { //si el token es nulo no está autorizado
            return Response.ok(token).build();
        } else {
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }

    }

    public String authenticate(String user, String pass) {

        //Usuario u = (Usuario)ManejarDB.verificarLogin(user, pass);
        String rol ="admin";
        return rol;
    }

    public String obtenerToken(String nombre, String rol, int time) {



        Date fechaExpiracion = new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(time));
        String token = Jwts
                .builder()
                .claim("roles", rol) //este es un claim particular, no estandar
                .setSubject(nombre) //tanto subject como expiration si son claims estandar
                .setExpiration(fechaExpiracion)
                .signWith(KeyClase.getKey()) //estamos cifrando el token con la clave previamente generada
                .compact();
        System.out.println(token);

        return token;
    }
}
