/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.carrito;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author alumno
 */
@Entity
@Table(name = "comentarios")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Comentarios.findAll", query = "SELECT c FROM Comentarios c")
    , @NamedQuery(name = "Comentarios.findByComentarioID", query = "SELECT c FROM Comentarios c WHERE c.comentarioID = :comentarioID")})
public class Comentarios implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "comentarioID")
    private Integer comentarioID;
    @Lob
    @Size(max = 65535)
    @Column(name = "contenido")
    private String contenido;
    @OneToMany(mappedBy = "comentarioID")
    private Collection<Producto> productoCollection;
    @JoinColumn(name = "usuarioID", referencedColumnName = "id_usuario")
    @ManyToOne
    private Usuario usuarioID;
    @JoinColumn(name = "productoID", referencedColumnName = "idProducto")
    @ManyToOne(optional = false)
    private Producto productoID;

    public Comentarios() {
    }

    public Comentarios(Integer comentarioID) {
        this.comentarioID = comentarioID;
    }

    public Integer getComentarioID() {
        return comentarioID;
    }

    public void setComentarioID(Integer comentarioID) {
        this.comentarioID = comentarioID;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    @XmlTransient
    public Collection<Producto> getProductoCollection() {
        return productoCollection;
    }

    public void setProductoCollection(Collection<Producto> productoCollection) {
        this.productoCollection = productoCollection;
    }

    public Usuario getUsuarioID() {
        return usuarioID;
    }

    public void setUsuarioID(Usuario usuarioID) {
        this.usuarioID = usuarioID;
    }

    public Producto getProductoID() {
        return productoID;
    }

    public void setProductoID(Producto productoID) {
        this.productoID = productoID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (comentarioID != null ? comentarioID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Comentarios)) {
            return false;
        }
        Comentarios other = (Comentarios) object;
        if ((this.comentarioID == null && other.comentarioID != null) || (this.comentarioID != null && !this.comentarioID.equals(other.comentarioID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.carrito.Comentarios[ comentarioID=" + comentarioID + " ]";
    }
    
}
