/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.carrito;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.mindrot.jbcrypt.BCrypt;

/**
 *
 * @author alumno
 */
public class Login extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet login</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet login at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        ArrayList<Producto> prod = null;

        if (request.getParameter("pag") == null || request.getParameter("pag") == "1") {
            prod = (ArrayList) ManejarDB.obtenerPaginaProductos(0);
        } else {
            int paginita = Integer.parseInt(request.getParameter("pag"));
            prod = (ArrayList) ManejarDB.obtenerPaginaProductos((paginita - 1) * 1);
        }
        session.setAttribute("totalprod", ManejarDB.obtenerTotalProductos());
        System.out.println("\n\n\n\n\n" + ManejarDB.obtenerTotalProductos());

        if (session.getAttribute("mapa") == null) {

            Pedidos ped = new Pedidos();
            Calendar calendar = Calendar.getInstance();

            java.sql.Date fecha = new java.sql.Date(calendar.getTime().getTime());

            ped.setFechaPedido(fecha.toString());
            session.setAttribute("pedido", ped);
            Integer total = 0;

            Map<Integer, Integer> mapa = new HashMap<>();
            session.setAttribute("mapa", mapa);

            session.setAttribute("total", total);
        }

        session.setAttribute("produc", prod);

        request.getRequestDispatcher("index.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nick = request.getParameter("nick");
        String pass = request.getParameter("passwd");
        HttpSession session = request.getSession();
 

        try {
            //Usuario u = ManejarDB.verificarLogin(nick, pass);
           Usuario u =  ManejarDB.obtenerPersonaByName(nick);
            if (nick.equals(u.getNick()) && pass.equals(u.getPasswd()) ||  BCrypt.checkpw(pass, u.getPasswd())) {
              Pedidos ped = (Pedidos) session.getAttribute("pedido");
                session.setAttribute("usuario", u);
                ped.setIdUsuario(u);

                RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
                rd.forward(request, response);

            }
        } catch (Exception e) {
            request.setAttribute("error", "ha introducido mal sus datos");
            RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
            rd.forward(request, response);
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
