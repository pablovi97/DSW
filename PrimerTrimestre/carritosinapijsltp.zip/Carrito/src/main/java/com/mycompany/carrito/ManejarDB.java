/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.carrito;

import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author alumno
 */
public class ManejarDB {

    static EntityManagerFactory emf;

    private static EntityManager crearEntityManager() {
        if (emf == null || (emf != null && !emf.isOpen())) {
            emf = Persistence.createEntityManagerFactory("unidadPersistencia");
        }
        return emf.createEntityManager();

    }

    public static void agregarUsuario(Usuario us) {

        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(us);
            et.commit();
        } catch (Exception ex) {

        }
        em.close();
    }

    public static void agregarComentario(Comentarios cm) {

        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(cm);
            et.commit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        em.close();
    }

    public static void modificarUsuario(Usuario us) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();
        try {

            et.begin();
            em.merge(us);
            et.commit();
        } catch (Exception e) {
        }

        em.close();
    }

    public static int obtenerTotalProductos() {
        EntityManager em = crearEntityManager();
        int i = em.createNamedQuery("Producto.findAll", Producto.class).getResultList().size();
        return i;
    }

    public static void borrarUsuario(int i) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();

            em.createNamedQuery("Usuario.deleteById", Usuario.class)
                    .setParameter("id", i)
                    .executeUpdate();

            et.commit();
        } catch (Exception e) {
            et.rollback();

        }

        em.close();

    }

    public static void agregarPedido(Pedidos ped) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();
        try {
            et.begin();
            em.persist(ped);
            et.commit();
        } catch (Exception e) {

        }

        em.close();
    }

    public static void modificarPedido(Pedidos ped) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();
        try {

            et.begin();
            em.merge(ped);
            et.commit();
        } catch (Exception e) {
        }

        em.close();
    }

    public static void borrarPedido(int i) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();

            em.createNamedQuery("Pedidos.deleteById", Pedidos.class)
                    .setParameter("id", i)
                    .executeUpdate();

            et.commit();
        } catch (Exception e) {
            et.rollback();

        }

        em.close();

    }

    public static Usuario verificarLogin(String nick, String pass) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();
        Usuario user = null;

        try {
            et.begin();

            user = em.createNamedQuery("Usuario.findByNickandpasswd", Usuario.class)
                    .setParameter("nick", nick)
                    .setParameter("passwd", pass)
                    .getSingleResult();

            et.commit();

        } catch (Exception e) {
            et.rollback();

        }

        em.close();
        return user;
    }

    public static boolean agregarDetallepedido(Pedidos p) {
        boolean res = false;
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();

            em.persist(p);
            //em.flush();
            for (DetallePedido dp : p.getDetallePedidoCollection()) {

                em.persist(dp);

            }
            res = true;
            et.commit();
        } catch (Exception e) {
        }

        em.close();
        return res;
    }

    public static void agregarDetallepedido2(DetallePedido p) {

        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();

            em.persist(p);

            et.commit();
        } catch (Exception e) {
        }

        em.close();

    }

    public static void agregarProducto(Producto prod) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        et.begin();
        em.persist(prod);
        et.commit();

        em.close();
    }

    public static void modificarProducto(Producto prod) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();
        try {

            et.begin();
            em.merge(prod);
            et.commit();
        } catch (Exception e) {
        }

        em.close();
    }

    public static Usuario obtenerPersonaByName(String nombre) {
        Usuario u = null;
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();

            u = (Usuario) em.createNamedQuery("Usuario.findByNick", Usuario.class)
                    .setParameter("nick", nombre)
                    .getSingleResult();

            et.commit();
        } catch (Exception e) {
            et.rollback();

        }

        em.close();
        return u;
    }

    public static Producto obtenerProductoByName(String nombre) {
        Producto pro = null;
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();

            pro = (Producto) em.createNamedQuery("Producto.findByNombreProducto", Producto.class)
                    .setParameter("nombreProducto", nombre)
                    .getSingleResult();

            et.commit();
        } catch (Exception e) {
            et.rollback();

        }

        em.close();
        return pro;
    }

    public static Producto obtenerProductoByid(int id) {
        Producto pro = null;
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();

            pro = (Producto) em.createNamedQuery("Producto.findByIdProducto", Producto.class)
                    .setParameter("idProducto", id)
                    .getSingleResult();

            et.commit();
        } catch (Exception e) {
            et.rollback();

        }

        em.close();
        return pro;
    }

    public static Pedidos obtenerPedidosByid(int id) {
        Pedidos ped = null;
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();

            ped = (Pedidos) em.createNamedQuery("Pedidos.findByIdPedido", Pedidos.class)
                    .setParameter("idPedido", id)
                    .getSingleResult();

            et.commit();
        } catch (Exception e) {
            et.rollback();

        }

        em.close();
        return ped;
    }

    public static ArrayList<Producto> obtenerProductos() {
        EntityManager em = crearEntityManager();

        ArrayList<Producto> lista = new ArrayList<Producto>(em.createNamedQuery("Producto.findAll", Producto.class).getResultList());

        return lista;
    }

    public static ArrayList<Pedidos> obtenerpedidos() {
        EntityManager em = crearEntityManager();

        ArrayList<Pedidos> lista = new ArrayList<>(em.createNamedQuery("Pedidos.findAll", Pedidos.class).getResultList());

        return lista;
    }

    public static ArrayList<Producto> obtenerPaginaProductos(int i) {
        EntityManager em = crearEntityManager();
        ArrayList<Producto> productos = new ArrayList<Producto>(em.createNamedQuery("Producto.findAll", Producto.class)
                .setFirstResult(i)
                .setMaxResults(1)
                .getResultList());
        return productos;
    }

    public static void borrarProducto(int i) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();

            em.createNamedQuery("Producto.deleteById", Producto.class)
                    .setParameter("id", i)
                    .executeUpdate();

            et.commit();
        } catch (Exception e) {
            et.rollback();

        }

        em.close();

    }

    public static ArrayList<Usuario> obtenerPersonas() {
        EntityManager em = crearEntityManager();
        ArrayList<Usuario> lista = new ArrayList<>();
        try {
            lista = (ArrayList<Usuario>) em.createNamedQuery("Usuario.findAll", Usuario.class).getResultList();
        } catch (Exception e) {
        }
        return lista;
    }

    public static void cerrarEntityManagerFactory() {
        if (emf != null && emf.isOpen()) {
            emf.close();
        }
    }
}
