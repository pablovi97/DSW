/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.foro;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author alumno
 */
public class ManejarDB {
     static EntityManagerFactory emf;

    private static EntityManager crearEntityManager() {
        if (emf == null || (emf != null && !emf.isOpen())) {
            emf = Persistence.createEntityManagerFactory("unidadPersistencia");
        }
        return emf.createEntityManager();

    }

    public static void agregarUsuario(Usuario us) {

        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try{
            et.begin();
            em.persist(us);
            et.commit();
        }catch(Exception ex){
           
        }
        em.close();
    }

    public static Usuario verificarLogin(String nombre, String password) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();
        Usuario user = null;

        try {
            et.begin();

            user = em.createNamedQuery("Usuario.findByNameAndPass", Usuario.class)
                    .setParameter("nombre", nombre)
                    .setParameter("password", password)
                    .getSingleResult();

            et.commit();

        } catch (Exception e) {
            et.rollback();

        }

        em.close();
        return user;
    }
    
    
    
    public static void modificarUsuario(Usuario us) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();
        try {

            et.begin();
            em.merge(us);
            et.commit();
        } catch (Exception e) {
        }

        em.close();
    }

    public static void borrarUsuario(int i) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();

            em.createNamedQuery("Usuario.deleteById", Usuario.class)
                    .setParameter("id", i)
                    .executeUpdate();

            et.commit();
        } catch (Exception e) {
            et.rollback();

        }
        }
    public static void agregarMensaje(Mensaje msn) {

        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try{
            et.begin();
            em.persist(msn);
            et.commit();
        }catch(Exception ex){
            
        }
        em.close();
    }

    public static void modificarMensaje(Mensaje msn) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();
        try {

            et.begin();
            em.merge(msn);
            et.commit();
        } catch (Exception e) {
        }

        em.close();
    }

    
    public static List<Foro> obtenerForos() {
        EntityManager em = crearEntityManager();
        List<Foro> lista = null;
        try {
            String query = "select f  from Foro f";
            lista = 
                    em.createQuery(query, Foro.class)
                    .getResultList();
            if(lista != null){
                for (Foro object : lista) {
                    System.out.println(object.getIdforo());
                }
            }
            
            /*
            lista = new ArrayList(em.createNamedQuery("Foro.findAll", Foro.class)
                    .getResultList());
*/
        } catch (Exception e) {
            e.printStackTrace();
        }
        em.close();
        return  lista;
    }
    
     
    public static Foro obtenerForosporID(int i) {
      EntityManager em = crearEntityManager();
      EntityTransaction et = em.getTransaction();
        Foro foro = null;
        try {
            et.begin();

           foro = em.createNamedQuery("Foro.findByIdforo", Foro.class)
                    .setParameter("idforo", i)
                    .getSingleResult();

            et.commit();
        } catch (Exception e) {
            et.rollback();

        }
        return foro;
    }
      public static Mensaje obtenerMensajeporID(int i) {
      EntityManager em = crearEntityManager();
      EntityTransaction et = em.getTransaction();
        Mensaje mens = null;
        try {
            et.begin();

           mens = em.createNamedQuery("Mensaje.findByIdmensaje", Mensaje.class)
                    .setParameter("idmensaje", i)
                    .getSingleResult();

            et.commit();
        } catch (Exception e) {
            et.rollback();

        }
        return mens;
    }
    public static void borrarMensaje(int i) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();

            em.createNamedQuery("Mensaje.deleteById", Mensaje.class)
                    .setParameter("idmensaje", i)
                    .executeUpdate();

            et.commit();
        } catch (Exception e) {
            et.rollback();

        }

        em.close();

    }
  
    
 public static void agregarForo(Foro foro) {

        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try{
            et.begin();
            em.persist(foro);
            et.commit();
        }catch(Exception ex){
            
        }
        em.close();
    }

    public static void modificarForo(Foro foro) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();
        try {

            et.begin();
            em.merge(foro);
            et.commit();
        } catch (Exception e) {
        }

        em.close();
    }

    public static void borrarForo(int i) {
        EntityManager em = crearEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();

            em.createNamedQuery("Foro.deleteById", Mensaje.class)
                    .setParameter("idforo", i)
                    .executeUpdate();

            et.commit();
        } catch (Exception e) {
            et.rollback();

        }

        em.close();

    }
  
}
