/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.foro;
import java.util.List;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import org.glassfish.jersey.jackson.JacksonFeature;

/**
 *
 * @author alumno
 */
public class ClienteRest {
    
    
     static   Client client = ClientBuilder.newClient().register(new JacksonFeature());
        
        
       
        public static List<Foro> obtenerListaforo(){
             List<Foro> foros = client
                .target("http://localhost:8080/foroRestApi/webresources/apirest.foro")
                .request(MediaType.APPLICATION_JSON)
                .get(new GenericType<List<Foro>>() {
                });
             System.out.println("FOROS");
             for (Foro foro : foros) {
                 System.out.println(foro);
            }
             return foros;
        }
       
         public static List<Usuario> obtenerListausuarios(){
             List<Usuario> users = client
                .target("http://localhost:8080/foroRestApi/webresources/apirest.usuario")
                .request(MediaType.APPLICATION_JSON)
                .get(new GenericType<List<Usuario>>() {
                });
             
             return users;
        }
            public static List<Mensaje> obtenerListamensajes(){
             List<Mensaje> mens = client
                .target("http://localhost:8080/foroRestApi/webresources/apirest.usuario")
                .request(MediaType.APPLICATION_JSON)
                .get(new GenericType<List<Mensaje>>() {
                });
             
             return mens;
        }

    
}
