<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class UsuarioResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'idkeyMostrada' => $this->id_usuario,
            'nombreKeyMostrada' => $this->nick,
            'pass' => $this->passwd,
            'rol' => $this->rol,
            ];
    }
}
