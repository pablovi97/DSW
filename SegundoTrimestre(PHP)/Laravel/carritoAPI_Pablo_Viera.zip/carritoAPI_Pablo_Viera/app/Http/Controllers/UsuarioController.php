<?php

namespace App\Http\Controllers;
use App\Http\Resources\UsuarioResource;
use App\Usuarios;
use Illuminate\Http\Request;

class UsuarioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->input('id_usuario') != null) {
            $parametroValue = $request->input('id_usuario');
            $PedidosFiltrados = Usuarios::where('id_usuario', 'like', $parametroValue)->get();
            return $PedidosFiltrados;
        }
        if ($request->input('nick') != null) {
            $parametroValue = $request->input('fechaPedido');
            $PedidosFiltrados = Usuarios::where('nick', 'like', $parametroValue)->get();
            return $PedidosFiltrados;
        }
        if ($request->input('rol') != null) {
            $parametroValue = $request->input('rol');
            $PedidosFiltrados = Usuarios::where('rol', 'like', $parametroValue)->get();
            return $PedidosFiltrados;
        }


        return UsuarioResource::collection(Usuarios::all());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Usuario  $usuario
     * @return \Illuminate\Http\Response
     */
    public function show(Usuarios $usuario)
    {
        return new UsuarioResource($usuario);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Usuario  $usuario
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Usuarios $usuario)
    {
        if (isset($usuario)) {
            $usuario->nick = $request->nom ?? $usuario->nick;
            $usuario->rol = $request->rol ?? $usuario->rol;
            $usuario->save();

            return new UsuarioResource($usuario);
        } else {
            return response()->json(['error' => ''], 403);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Usuario  $usuario
     * @return \Illuminate\Http\Response
     */
    public function destroy(Usuarios $usuario)
    {
        $usuario->delete();


        return response()->json(null, 204);
    }
}
